<?php
define('CONSUMER_KEY', 'ZrzMR8ZihvKBEAgxwtTywo6vZ');
define('CONSUMER_SECRET', 'wFNADpQHc5KljhTSi7TD3QJEiUB0ZjDzpfSVYLyf4VrinVA2uk');
define('OAUTH_CALLBACK', 'http://www.w3tweaks.com/twitterlogin/process.php');
?>