Author: W3tweaks
Author URL: http://www.w3tweaks.com/
Author Email: w3tweaks@gmail.com

============Steps to Follow============
1. Create a database (twitterlogin) at phpMyAdmin.
2. Import the users.sql file into the database (twitterlogin).
3. Open the "includes/functions.php" file and modify the $dbServer, $dbUsername, $dbPassword, $dbName variables value with your phpMyAdmin details.
4. Open the "config.php" file and modify the CONSUMER_KEY, CONSUMER_SECRET, OAUTH_CALLBACK constant value with your twitter apps details.
5. Test the functionalities.

============ May I Help You ===========
If you have any query about this script, please feel free to contact us at w3tweaks@gmail.com. We will reply your query soon.